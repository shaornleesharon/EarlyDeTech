//
//  ViewController.swift
//  testingar
//
//  Created by Sharon Lee on 2/15/20.
//  Copyright © 2020 Sharon Lee. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import AVFoundation

class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!
    
    //variables to measure eye movement
    var travTime = 0.0
    var distance = 0.0
    var latency = 0.0
    var gains = 0.0
    var velocity = 0.0
    var precision = 0.0
    var posPres = 0.0
    var negPres = 0.0
    var avgDist1 = 0.0
    var avgDist2 = 0.0
    var avgDist3 = 0.0
    
    //detect each criterion for parkinson's
    var latTrig = false
    var velTrig = false
    var gainTrig = false
    var presTrig = false
    
    //variables used to run the code
    var timerR : Timer!
    var timerGo : Timer!
    let beep: SystemSoundID = 1022
    var coords = SIMD3<Float>()
    var pastCoords = SIMD3<Float>()
    var coordArr : [SIMD3<Float>] = []
    
    var go = false
    var pastGo = false
    var going = false
    var stop = false
    var stopped = false
    var right = false
    var left = false
    var timeGo = 0.0
    var timeReach = 0.0
    var timePass = 0.0
    var tests = 0
    var timeReachArr : [Double] = []
    var timeGoArr : [Double] = []
    
    
    
    var type = "Good news! We couldn't detect any early signs of Parkinson's Disease."
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.delegate = self
        sceneView.showsStatistics = true
        
        //make sure device supports face tracking
        guard ARFaceTrackingConfiguration.isSupported else {
            fatalError("Face tracking is not supported on this device")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARFaceTrackingConfiguration()

        // Run the view's session
        sceneView.session.run(configuration)
        
        //begin by looking right
        timerR = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(lookRight), userInfo: nil, repeats: true)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    //saves calculated data on user's chance of parkinson's
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is TertiaryViewController
        {
            let vc = segue.destination as? TertiaryViewController
            vc?.precision = precision
            vc?.latency = latency
            vc?.gains = gains
            vc?.velocity = velocity
        }
    }

    //ensure user looks to the side
    @objc func lookRight() {
        if right {
            timerR.invalidate()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                //check if still stopped, else RESET TIMER
                if self.right{
                    self.countTime()
                }
                else {
                    self.timerR = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.lookRight), userInfo: nil, repeats: true)
                }
            })
        }
    }
    
    //measures time taken for eye movements
    func countTime() {
        AudioServicesPlaySystemSound(self.beep)
        timerGo = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            self.timePass += 0.05
            if self.going && (self.timeGo == 0.0) {
                self.timeGo = self.timePass
            }
            if (self.timeGo != 0.0) && self.stop {
                self.timeReach = self.timePass
                self.timerGo.invalidate()
                print(self.timeGo) //time taken to start moving (latency)
                print(self.timeReach) //time taken to reach destination (velocity)
                self.tests += 1
                if self.tests <= 6 {
                    self.coordArr.append(self.coords)
                    self.timeGoArr.append(self.timeGo)
                    self.timeReachArr.append(self.timeReach)
                    self.timeGo = 0.0
                    self.timeReach = 0.0
                    self.timePass = 0.0
                    //three times for each side
                    if self.tests < 6 {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                            self.countTime()
                        })
                    }
                    else {
                        //display recorded data to console
                        print(self.coordArr)
                        print(self.timeGoArr)
                        print(self.timeReachArr)
                        self.calculate()
                    }
                }
                    
                
                    
            }
        }
    }
    
    //calculates parkinson's related factors
    func calculate() {
        distance = abs(Double(coordArr[0].x - coordArr[1].x))
        latency = timeGoArr.reduce(0, +) / Double(timeGoArr.count)
        travTime = timeReachArr.reduce(0, +) / Double(timeReachArr.count)
        velocity = distance / travTime
        posPres = Double(abs(coordArr[0].x - coordArr[2].x) + abs(coordArr[0].x - coordArr[4].x))
        negPres = Double(abs(coordArr[1].x - coordArr[3].x) + abs(coordArr[1].x - coordArr[5].x))
        precision = posPres + negPres
        avgDist1 = abs(Double(coordArr[0].x - coordArr[1].x))
        avgDist2 = abs(Double(coordArr[2].x - coordArr[3].x))
        avgDist3 = abs(Double(coordArr[4].x - coordArr[5].x))
        gains = ((avgDist2 + avgDist3) / 2) / avgDist1
        
        presTrig = precision > 3
        latTrig = latency > 3
        velTrig = velocity < 0.002
        gainTrig = gains < 0.05
        
        if presTrig && latTrig && velTrig && gainTrig {
            type = "You may be at risk for Parkinson's Disease 9."
        }
        else if latTrig && presTrig {
            type = "You may be at risk for Parkinson's Disease (Hereditary)."
        }
        else if gainTrig {
            type = "You may be at risk for Parkinson's Disease 2."
        }
        else if latTrig {
            type = "You may be at risk for Parkinson's Disease 1/6."
        }
        else {
            type = "Good news! We couldn't detect any early signs of Parkinson's Disease."
        }
    }
    
    // MARK: - ARSCNViewDelegate
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let faceMesh = ARSCNFaceGeometry(device: sceneView.device!)
        let node = SCNNode(geometry: faceMesh)
        node.geometry?.firstMaterial?.fillMode = .lines
        return node
    }
    
    //measure eye movement and position
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        if let faceAnchor = anchor as? ARFaceAnchor, let faceGeometry = node.geometry as? ARSCNFaceGeometry {
            faceGeometry.update(from: faceAnchor.geometry)
            pastCoords = coords
            coords = faceAnchor.lookAtPoint
            right = coords.x > 0.1
            left = coords.x < -0.1
            
            pastGo = go
            go = abs(pastCoords.x - coords.x) > 0.015
            going = pastGo && go
            stop = !going
            
            print(coords)
            if right {
                print("right")
            }
            if left {
                print("left")
            }
        }
    }

/*
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
     
        return node
    }
*/
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}
